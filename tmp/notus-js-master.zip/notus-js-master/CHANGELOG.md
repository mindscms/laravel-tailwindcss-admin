# Change Log

## [1.0.0] 2020-09-29
### Original Release
- Started project from [Tailwind Starter Kit by Creative Tim](https://www.creative-tim.com/learning-lab/tailwind-starter-kit/presentation?ref=njs-changelog)
- Added design from Tailwind Starter Kit by Creative Tim
